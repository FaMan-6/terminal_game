fun mulaiGame(namaKarakter: String, streghPlayer: Int, healthPlayer: Int, hungerBar: Int) {

    var mushroomRabbitStregh = 30

    println("$namaKarakter akan melawan moster Mushroom Rabbit🍄🐰 yang memiliki kekuatan $mushroomRabbitStregh \n" +
            "di turnament Monster Hunter, "+
            "sedangkan $namaKarakter baru memiliki kekuatan $streghPlayer.\n " +
            "pertandingan akan dimulai sebulan dari sekarang apa yang akan kamu lakukan?")

    println("\"TUNGGU\" -> pasrah dan menunggu hari pertandingan\n" +
            "atau\n" +
            "\"LATIHAN\" -> latihan untuk meningkatkan kekuatan dan keahlian")
    var userKontrol = readln().toString()

    if (userKontrol == "TUNGGU" || userKontrol == "tunggu"){
        println("Menunggu🛌")
        tunggu(namaKarakter, streghPlayer, healthPlayer, hungerBar)
    }else if (userKontrol == "LATIHAN" || userKontrol == "latihan"){

        println("Latihan🏋️‍♂️")
        latihan(namaKarakter, streghPlayer, healthPlayer, hungerBar)
    }
}