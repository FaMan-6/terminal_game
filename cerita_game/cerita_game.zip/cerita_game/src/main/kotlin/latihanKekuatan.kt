fun latihanKekuatan(namaKarakter: String, streghPlayer: Int, healthPlayer: Int, hungerBar: Int) {
    print("masuk ke kekuatan")
}