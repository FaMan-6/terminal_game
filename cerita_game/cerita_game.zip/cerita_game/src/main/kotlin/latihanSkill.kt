fun latihanSkill(){
    print("Masuk ke skill")
}