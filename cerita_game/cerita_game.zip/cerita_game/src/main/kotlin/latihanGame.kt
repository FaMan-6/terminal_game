fun latihan(namaKarakter: String, streghPlayer: Int, healthPlayer: Int, hungerBar: Int) {

    print("$namaKarakter berniat untuk berlatih agar kekuatannya bertambah \n" +
            "dan bisa mengalahkan monster Mushroom Rabbit")
    readln()
    println("pilih latihan🏋️‍♂️")
    println("\"KEKUATAN\" -> untuk melatih kekuatan $namaKarakter 💪\n" +
            "atau\n" +
            "\"KECEPATAN\" -> untuk melatih kecepatan $namaKarakter 🏃‍♂️\n" +
            "atau\n" +
            "\"SKILL\" -> untuk mendapatkan skill baru🦸‍♂️🧙🪄")

    var userKontrol = readln()

    if (userKontrol == "KEKUATAN" || userKontrol == "kekuatan"){

        latihanKekuatan(namaKarakter, streghPlayer, healthPlayer, hungerBar)
    }else if (userKontrol == "KECEPATAN" || userKontrol == "kecepatan"){

        lathanKecepatan(namaKarakter, streghPlayer, healthPlayer, hungerBar)
    }else if (userKontrol == "SKILL" || userKontrol == "skill"){

        latihanSkill()
    }
}