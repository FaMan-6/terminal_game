fun jalanJalan(namaKarakter: String, streghPlayer: Int, healthPlayer: Int, hungerBar: Int) {

}